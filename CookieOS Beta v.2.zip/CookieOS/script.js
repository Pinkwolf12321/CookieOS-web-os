let maxZ = 10;

document.addEventListener('DOMContentLoaded', () => {
  // Open and Close Windows
  window.openWindow = function(id) {
    const win = document.getElementById(id);
    if (win) {
      win.style.display = 'block';
      maxZ++;
      win.style.zIndex = maxZ;
      win.focus?.();
    }
    document.getElementById('app-menu').style.display = 'none';
  };

  window.closeWindow = function(id) {
    const win = document.getElementById(id);
    if (win) win.style.display = 'none';
  };

  // Calculator
  let calcDisplay = document.getElementById('calculator-display');
  let calcExpression = '';

  window.calcPress = function(val) {
    if (calcExpression === '0' && val !== '.') {
      calcExpression = val;
    } else {
      calcExpression += val;
    }
    calcDisplay.value = calcExpression;
  };

  window.calcClear = function() {
    calcExpression = '';
    calcDisplay.value = '0';
  };

  window.calcEquals = function() {
    try {
      if (/^[0-9+\-*/.() ]+$/.test(calcExpression)) {
        calcExpression = eval(calcExpression).toString();
        calcDisplay.value = calcExpression;
      } else {
        calcDisplay.value = 'Error';
      }
    } catch {
      calcDisplay.value = 'Error';
    }
  };

  // Mini Browser
  document.getElementById('browser-go').addEventListener('click', () => {
    let url = document.getElementById('browser-url').value.trim();
    if (!url) return;
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    document.getElementById('browser-frame').src = url;
  });

  // IDE
  document.getElementById('ide-run').addEventListener('click', () => {
    const editor = document.getElementById('ide-editor');
    const output = document.getElementById('ide-output');
    output.textContent = '';
    try {
      const result = eval(editor.value);
      output.textContent = result === undefined ? 'Done.' : result;
    } catch (err) {
      output.textContent = 'Error: ' + err.message;
    }
  });

  // Terminal
  (function() {
    const output = document.getElementById('terminal-output');
    const input = document.getElementById('terminal-input');
    const prompt = 'cookieos> ';
    let history = [], historyIndex = -1;
    const virtualFiles = ['notes.txt', 'todo.md', 'cookie_recipe.html'];

    function printLine(text = '') {
      output.innerHTML += text + '<br>';
      output.scrollTop = output.scrollHeight;
    }

    function runCommand(cmd) {
      const parts = cmd.trim().split(' ');
      const base = parts[0].toLowerCase();
      const args = parts.slice(1);

      switch(base) {
        case '':
          break;
        case 'help':
          printLine('Commands: help, echo, clear, date, about, ls, calc, repeat');
          break;
        case 'echo':
          printLine(args.join(' '));
          break;
        case 'clear':
          output.innerHTML = '';
          break;
        case 'date':
          printLine(new Date().toString());
          break;
        case 'about':
          printLine('CookieOS Terminal Beta 1 © 2025 Blyth Laiman Karl. All rights reserved.');
          break;
        case 'ls':
          printLine(virtualFiles.join(' '));
          break;
        case 'calc':
          try {
            const expression = args.join('');
            if (/^[0-9+\-*/(). ]+$/.test(expression)) {
              const result = eval(expression);
              printLine(result);
            } else {
              printLine('Invalid characters in expression.');
            }
          } catch {
            printLine('Error calculating expression.');
          }
          break;
        case 'repeat':
          const times = parseInt(args[0]);
          if (!isNaN(times) && times > 0) {
            const text = args.slice(1).join(' ');
            for (let i = 0; i < times; i++) printLine(text);
          } else {
            printLine('Usage: repeat [times] [text]');
          }
          break;
        default:
          printLine(`Unknown command: ${base}`);
          break;
      }
    }

    input.addEventListener('keydown', (e) => {
      if (e.key === 'Enter') {
        const cmd = input.value;
        printLine(`<span style="color:#00fff7;">${prompt}${cmd}</span>`);
        runCommand(cmd);
        history.push(cmd);
        historyIndex = history.length;
        input.value = '';
      } else if (e.key === 'ArrowUp') {
        if (historyIndex > 0) {
          historyIndex--;
          input.value = history[historyIndex];
        }
      } else if (e.key === 'ArrowDown') {
        if (historyIndex < history.length - 1) {
          historyIndex++;
          input.value = history[historyIndex];
        } else {
          historyIndex = history.length;
          input.value = '';
        }
      }
    });

    printLine('Welcome to CookieOS Terminal! Type "help" for commands.');
  })();

  // App Uploading
  function uploadApp() {
    const fileInput = document.getElementById('app-file');
    const status = document.getElementById('upload-status');

    if (fileInput.files.length === 0) {
      status.textContent = 'Please select a file.';
      status.style.color = 'red';
      return;
    }

    const file = fileInput.files[0];
    if (!file.name.endsWith('.html')) {
      status.textContent = 'Only .html files allowed.';
      status.style.color = 'red';
      return;
    }

    const reader = new FileReader();
    reader.onload = function(e) {
      const content = e.target.result;
      addUploadedApp(file.name, content);
      status.textContent = `App "${file.name}" uploaded!`;
      status.style.color = 'green';
      fileInput.value = '';
    };
    reader.readAsText(file);
  }
  window.uploadApp = uploadApp;

  // Uploaded apps
  const uploadedApps = [];

  function addUploadedApp(name, content) {
    uploadedApps.push({name, content});
    refreshUploadedApps();
  }

  function refreshUploadedApps() {
    const container = document.getElementById('uploaded-apps');
    container.innerHTML = '';
    uploadedApps.forEach((app, idx) => {
      const btn = document.createElement('button');
      btn.className = 'app-launch';
      btn.textContent = app.name;
      btn.onclick = () => openUploadedApp(idx);
      container.appendChild(btn);
    });
  }

  function openUploadedApp(index) {
    const app = uploadedApps[index];
    if (!app) return;

    let win = document.getElementById('uploaded-app-' + index);
    if (!win) {
      win = document.createElement('div');
      win.id = 'uploaded-app-' + index;
      win.className = 'window';
      win.style.top = '100px';
      win.style.left = (100 + index * 20) + 'px';
      win.style.width = '400px';
      win.style.height = '300px';
      win.style.display = 'block';

      const titleBar = document.createElement('div');
      titleBar.className = 'title-bar';
      titleBar.textContent = app.name;

      const closeBtn = document.createElement('span');
      closeBtn.className = 'close-btn';
      closeBtn.innerHTML = '&times;';
      closeBtn.onclick = () => win.style.display = 'none';
      titleBar.appendChild(closeBtn);

      win.appendChild(titleBar);

      const iframe = document.createElement('iframe');
      iframe.style.width = '100%';
      iframe.style.height = 'calc(100% - 30px)';
      iframe.style.border = 'none';

      const blob = new Blob([app.content], {type: 'text/html'});
      const url = URL.createObjectURL(blob);
      iframe.src = url;

      win.appendChild(iframe);
      document.body.appendChild(win);
      makeDraggable(win);
    } else {
      win.style.display = 'block';
    }
    maxZ++;
    win.style.zIndex = maxZ;
  }
  window.openUploadedApp = openUploadedApp;

  // Launcher menu
  const preinstalled = [
    {name: 'Calculator', id: 'calculator'},
    {name: 'Mini Browser', id: 'browser'},
    {name: 'IDE', id: 'ide'},
    {name: 'Terminal', id: 'terminal'},
    {name: 'Upload App', id: 'app-uploader'}
  ];

  function refreshPreinstalledApps() {
    const container = document.getElementById('preinstalled-apps');
    container.innerHTML = '';
    preinstalled.forEach(app => {
      const btn = document.createElement('button');
      btn.className = 'app-launch';
      btn.textContent = app.name;
      btn.onclick = () => openWindow(app.id);
      container.appendChild(btn);
    });
  }

  document.getElementById('launcher-btn').addEventListener('click', () => {
    const menu = document.getElementById('app-menu');
    menu.style.display = (menu.style.display === 'block') ? 'none' : 'block';
  });

  // Make draggable
  function makeDraggable(win) {
    const titleBar = win.querySelector('.title-bar');
    if (!titleBar) return;

    let offsetX = 0, offsetY = 0, dragging = false;

    titleBar.style.cursor = 'grab';

    titleBar.addEventListener('mousedown', (e) => {
      dragging = true;
      offsetX = e.clientX - win.offsetLeft;
      offsetY = e.clientY - win.offsetTop;
      titleBar.style.cursor = 'grabbing';
      win.style.userSelect = 'none';
      maxZ++;
      win.style.zIndex = maxZ;
      e.preventDefault();
    });

    document.addEventListener('mouseup', () => {
      dragging = false;
      titleBar.style.cursor = 'grab';
      win.style.userSelect = '';
    });

    document.addEventListener('mousemove', (e) => {
      if (dragging) {
        let newX = e.clientX - offsetX;
        let newY = e.clientY - offsetY;
        const maxX = window.innerWidth - win.offsetWidth;
        const maxY = window.innerHeight - win.offsetHeight - 50;
        if (newX < 0) newX = 0;
        if (newY < 0) newY = 0;
        if (newX > maxX) newX = maxX;
        if (newY > maxY) newY = maxY;
        win.style.left = newX + 'px';
        win.style.top = newY + 'px';
      }
    });
  }

// Splash screen logic
const splash = document.getElementById('splash');
let maxZ = 10; // make sure this matches your existing maxZ variable if declared globally

function hideSplash() {
  splash.classList.add('fade-out');
  splash.addEventListener('animationend', () => {
    splash.style.display = 'none';
    document.body.style.overflow = 'auto'; // re-enable scrolling if needed
  });
}

// Fake loading time between 3 and 9 seconds
const fakeLoadTime = Math.random() * 6000 + 3000;

window.addEventListener('load', () => {
  document.body.style.overflow = 'hidden'; // disable scrolling during splash
  setTimeout(hideSplash, fakeLoadTime);
});

  // Initialize
  refreshPreinstalledApps();
  ['calculator', 'browser', 'ide', 'terminal', 'app-uploader'].forEach(id => {
    const win = document.getElementById(id);
    if (win) makeDraggable(win);
  });
});